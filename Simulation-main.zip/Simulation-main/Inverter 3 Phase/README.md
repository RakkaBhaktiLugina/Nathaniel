## Simulation

# Circuit Diagram
 
<img width="5012" height="4516" alt="schematic" src="https://github.com/user-attachments/assets/6d85f719-dcdd-410d-8452-4e31f60a9cab" />

# Result
![scope_pages-to-jpg-0001](https://github.com/user-attachments/assets/d24c75e9-6c1e-4697-a5d6-3099273a7421)

![scope1_pages-to-jpg-0001](https://github.com/user-attachments/assets/76e681a1-d1aa-46e8-ada4-8d92263b542c)
