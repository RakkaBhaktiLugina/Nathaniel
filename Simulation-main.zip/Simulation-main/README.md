Berisi mengenai simulalasi rangkaian inverter
